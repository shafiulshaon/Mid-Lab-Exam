<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") 
{


	$name = test_input($_POST["name"]);
  $email = $_POST["email"];
  $uname = test_input($_POST["userName"]);
  $pass = test_input($_POST["password"]);
  $gender;
  $dob =$_POST['dd'].'/'.$_POST['mm'].'/'.$_POST['yyyy'];




  $confirmpass = test_input($_POST["confirmPassword"]);

  if (empty($_POST["name"])) 
  {
	 echo "Name is required";
  } 
  elseif(!preg_match("/^[a-zA-Z ]*$/",$name))
  {
		echo "Only letters and white space allowed";
  }
   
  else
  {
	if (str_word_count($name)<2)
			echo "not 2 words";
	else
		echo $_POST["name"];
  }  
 


  if (empty($_POST["email"])) 
  {
	 echo "Email is required";
  } 
  elseif(!preg_match("/^[a-zA-Z0-9-_.]+@[a-zA-Z-]+\.[a-zA-Z.]{2,5}$/",$_POST["email"]))
  {
		echo "Emain not valid";
  }
   
  else
  {
		//echo $_POST["email"];
  }  
 

	
  if (empty($_POST["userName"])) 
  {
	 echo "User name is required";
  }    
  else
  {
		//echo $_POST["userName"];
  }  
 

	
  if (empty($_POST["password"])) 
  {
	 echo "Password is required";
  } 
	elseif(($_POST["confirmPassword"])!==($_POST["password"]))
		echo "Password did not match";
  else
  {
		//echo $_POST["password"];
  }  
 

		if(empty($_POST['gender']))
		echo "Please select at least one";
	else
    $gender= "Male";


		if(isset($_POST['dd']) || isset($_POST['mm']) || isset($_POST['yyyy']))
	{
	if(empty($_POST['dd']) || empty($_POST['mm']) || empty($_POST['yyyy']))
	echo "invalid format";
	else
	{	
		//{echo $_POST['dd'].'/'.$_POST['mm'].'/'.$_POST['yyyy'];}
	}
	}



        $servername   ="localhost";
        $username   ="root";
        $password   ="";
        $dbname       ="midlabexam";
  
        $conn = mysqli_connect($servername, $username, $password, $dbname);
  
       if(!$conn)
       {
      die("Connection Error!".mysqli_connect_error());
     }
     else
     {
      $sql = "insert into user values ('$name','$email','$uname','$pass','$gender','$dob')";
  
          if(mysqli_query($conn, $sql))
          {
        echo "<br/> Data Inserted!";
        header("Location: login.php");
          }
          else
          {
        echo "<br/> SQL Error".mysqli_error($conn);
          }
          mysqli_close($conn);



    }


}
function test_input($data) 
{
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
?>